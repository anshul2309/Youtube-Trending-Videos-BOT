from tkinter import *

window = Tk()
window.title("ATLAS")
window.configure(background = 'black')

#pic
#click function/keydown
def click():
    entered_text= textentry.get()
    output.delete(0.0, END)
    try:
        definition = my_dic[entered_text]
    except:
        definition = ' sorry it will shut down now!'
    output.insert(END, definition)    


def close_window():
    window.destroy()
    exit()


#label
Label(window, text= " Enter a country",bg='black',fg='white',font='none 12 bold').grid(row=1,column=3,sticky=W) 

#textbox

textentry = Entry(window, width =20, bg='white')
textentry.grid(row=5,column=2,sticky=W)


#submit
Button(window,text='SUBMIT', width=6,command=click).grid(row=8,column=4,sticky=W)


#output

output = Text(window,width = 75, height=6,wrap = WORD, background = "white")
output.grid(row=15, column =1,columnspan=2,sticky=W)

#dictonary

my_dic = {'asia': 'continent', 'australia' : 'small continent'}

#exitlabel

Label(window, text= " EXIT",bg='black',fg='white',font='none 12 bold').grid(row=20,column=1,sticky=W)


#exitbutton

Button(window,text='EXIT', width=6,command=close_window).grid(row=23,column=1,sticky=W)

#exitfunction



#last

window.mainloop()

